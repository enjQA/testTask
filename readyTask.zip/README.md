Command for run: node index.js

